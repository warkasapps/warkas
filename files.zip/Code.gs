/**
 * WARKAS — Backend Apps Script (v3: API murni buat dipanggil dari luar)
 * ================================================================
 * Tampilan aplikasinya sekarang di-hosting TERPISAH (GitHub Pages), bukan di
 * sini lagi — supaya bisa jadi PWA beneran (manifest + service worker butuh
 * halaman biasa di luar iframe Apps Script).
 *
 * File ini cuma jadi API: terima request dari luar lewat doPost(), format:
 *   { action: "namaAction", payload: {...} }
 * dan balas JSON: { ok: true, data: ... } atau { ok: false, error: "..." }
 */

const GUDANG = "Gudang Pusat";

// ---------- ENTRY POINTS ----------

function doGet(e) {
  return jsonResponse({ ok: true, message: "Warkas API aktif. Gunakan POST untuk mengakses data." });
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const action = body.action;
    const payload = body.payload || {};
    const handlers = {
      login: doLogin,
      getBootstrap: doGetBootstrap,
      getTransaksi: doGetTransaksi,
      getPresensiSaya: function (p) { return doGetPresensiSaya(p.pegawaiId); },
      recordSale: doRecordSale,
      recordPurchase: doRecordPurchase,
      recordTransfer: doRecordTransfer,
      recordAbsen: doRecordAbsen,
    };
    if (!handlers[action]) return jsonResponse({ ok: false, error: "Action tidak dikenal: " + action });
    const result = handlers[action](payload);
    return jsonResponse({ ok: true, data: result });
  } catch (err) {
    return jsonResponse({ ok: false, error: err.message });
  }
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// ---------- HELPERS: baca/tulis sheet sebagai array of object ----------

function sheet(name) {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
}

function readAll(name) {
  const sh = sheet(name);
  const values = sh.getDataRange().getValues();
  const headers = values[0];
  return values.slice(1).filter((row) => row.some((c) => c !== "")).map((row) => {
    const obj = {};
    headers.forEach((h, i) => (obj[h] = row[i]));
    return obj;
  });
}

function appendRow(name, obj, headers) {
  const sh = sheet(name);
  const row = headers.map((h) => (obj[h] !== undefined ? obj[h] : ""));
  sh.appendRow(row);
}

function newId(prefix) {
  return prefix + "_" + Utilities.getUuid().slice(0, 8);
}

// ---------- LOGIN ----------

function doLogin(p) {
  const users = readAll("Users");
  const found = users.find((u) => u.username === p.username && String(u.password) === String(p.password));
  if (!found) throw new Error("Username atau password salah.");
  const clean = Object.assign({}, found);
  delete clean.password;
  return clean;
}

// ---------- BOOTSTRAP: semua data master + stok saat ini ----------

function doGetBootstrap() {
  const bahan = readAll("BahanBaku");
  const stokRows = readAll("StokLokasi");
  const stokMap = {};
  stokRows.forEach((r) => {
    if (!stokMap[r.bahanId]) stokMap[r.bahanId] = {};
    stokMap[r.bahanId][r.lokasi] = r.qty;
  });
  bahan.forEach((b) => (b.stok = stokMap[b.id] || {}));

  const produk = readAll("Produk");
  const resep = readAll("Resep");
  produk.forEach((p) => {
    p.outlets = String(p.outletAktif || "").split(",").map((s) => s.trim()).filter(Boolean);
    p.resep = resep.filter((r) => r.produkId === p.id).map((r) => ({ b: r.bahanId, qty: r.qty }));
  });

  const supplier = readAll("Supplier");
  supplier.forEach((s) => (s.bahan = String(s.bahanDisuplai || "").split(",").map((x) => x.trim()).filter(Boolean)));

  const outlets = [];
  readAll("JamOperasional").forEach((j) => { if (j.lokasi !== GUDANG) outlets.push(j.lokasi); });

  return {
    bahan: bahan, produk: produk, supplier: supplier, outlets: outlets, gudangNama: GUDANG,
    jamOperasional: readAll("JamOperasional"), employees: readAll("Employees"),
  };
}

// ---------- PRESENSI ----------

function doGetPresensiSaya(pegawaiId) {
  return readAll("Presensi").filter((p) => p.pegawaiId === pegawaiId).sort((a, b) => String(b.tanggal).localeCompare(String(a.tanggal)));
}

function apiGetPresensiSaya(pegawaiId) {
  return doGetPresensiSaya(pegawaiId);
}

function doRecordAbsen(p) {
  const tz = Session.getScriptTimeZone();
  const today = Utilities.formatDate(new Date(), tz, "yyyy-MM-dd");
  const jamSekarang = Utilities.formatDate(new Date(), tz, "HH:mm");
  const sh = sheet("Presensi");
  const values = sh.getDataRange().getValues();
  let rowIdx = -1;
  for (let i = 1; i < values.length; i++) {
    if (values[i][1] === p.pegawaiId && values[i][2] === today) { rowIdx = i + 1; break; }
  }

  if (p.tipe === "pulang") {
    if (rowIdx === -1) throw new Error("Belum ada absen masuk hari ini.");
    sh.getRange(rowIdx, 6).setValue(jamSekarang);
    return { jamPulang: jamSekarang };
  }

  const employees = readAll("Employees");
  const emp = employees.find((e) => e.id === p.pegawaiId);
  const shiftMulai = (emp && emp.shiftMulai) || "08:00";
  const batasTelat = tambahMenit(shiftMulai, 15);
  const status = jamSekarang > batasTelat ? "telat" : "hadir";
  if (rowIdx !== -1) {
    sh.getRange(rowIdx, 4).setValue(status);
    sh.getRange(rowIdx, 5).setValue(jamSekarang);
  } else {
    sh.appendRow([p.pegawaiId + "-" + today, p.pegawaiId, today, status, jamSekarang, ""]);
  }
  return { status: status, jamMasuk: jamSekarang };
}

function tambahMenit(hhmm, menit) {
  const parts = String(hhmm).split(":").map(Number);
  const total = parts[0] * 60 + parts[1] + menit;
  const nh = String(Math.floor(total / 60) % 24).padStart(2, "0");
  const nm = String(total % 60).padStart(2, "0");
  return nh + ":" + nm;
}

// ---------- BACA TRANSAKSI (untuk Riwayat) ----------

function doGetTransaksi() {
  const jual = readAll("TransaksiJual");
  const jualItem = readAll("TransaksiJualItem");
  jual.forEach((j) => (j.items = jualItem.filter((it) => it.jualId === j.id)));
  return {
    jual: jual.sort((a, b) => new Date(b.waktu) - new Date(a.waktu)).slice(0, 30),
    beli: readAll("TransaksiBeli").sort((a, b) => new Date(b.waktu) - new Date(a.waktu)).slice(0, 30),
    transfer: readAll("TransaksiTransfer").sort((a, b) => new Date(b.waktu) - new Date(a.waktu)).slice(0, 30),
  };
}

// ---------- STOK: baca & ubah ----------

function getStok(bahanId, lokasi) {
  const sh = sheet("StokLokasi");
  const values = sh.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === bahanId && values[i][1] === lokasi) return { row: i + 1, qty: values[i][2] };
  }
  return null;
}

function ubahStok(bahanId, lokasi, delta) {
  const sh = sheet("StokLokasi");
  const existing = getStok(bahanId, lokasi);
  if (existing) {
    const baru = existing.qty + delta;
    sh.getRange(existing.row, 3).setValue(baru);
    return baru;
  } else {
    sh.appendRow([bahanId, lokasi, delta]);
    return delta;
  }
}

// ---------- JUAL (checkout keranjang) ----------
// payload: { lokasi, oleh, channel, items:[{produkId, qty}], pelangganNama, pelangganHp }

function doRecordSale(p) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const produkList = readAll("Produk");
    const resep = readAll("Resep");

    const kebutuhan = {};
    const itemDetail = [];
    let totalKotor = 0;

    p.items.forEach((it) => {
      const produk = produkList.find((x) => x.id === it.produkId);
      if (!produk) throw new Error("Produk tidak ditemukan: " + it.produkId);
      const harga = p.channel === "offline" ? produk.harga : produk.hargaOnline;
      const subtotal = harga * it.qty;
      totalKotor += subtotal;
      itemDetail.push({ produkId: produk.id, namaProduk: produk.nama, qty: it.qty, harga: harga, subtotal: subtotal });

      resep.filter((r) => r.produkId === produk.id).forEach((r) => {
        kebutuhan[r.bahanId] = (kebutuhan[r.bahanId] || 0) + r.qty * it.qty;
      });
    });

    Object.keys(kebutuhan).forEach((bahanId) => {
      const stok = getStok(bahanId, p.lokasi);
      const tersedia = stok ? stok.qty : 0;
      if (tersedia < kebutuhan[bahanId]) {
        throw new Error("Stok tidak cukup untuk bahan " + bahanId + " di " + p.lokasi);
      }
    });

    Object.keys(kebutuhan).forEach((bahanId) => ubahStok(bahanId, p.lokasi, -kebutuhan[bahanId]));

    const KOMISI = { offline: 0, gofood: 20, shopeefood: 20, grabfood: 18 };
    const komisiPersen = KOMISI[p.channel] != null ? KOMISI[p.channel] : 0;
    const komisi = Math.round(totalKotor * (komisiPersen / 100));

    const now = new Date();
    const periode = Utilities.formatDate(now, Session.getScriptTimeZone(), "yyyyMM");
    const jualSemua = readAll("TransaksiJual");
    const urutan = jualSemua.filter((j) => String(j.orderNo).indexOf(periode) === 0).length + 1;
    const orderNo = periode + String(urutan).padStart(3, "0");

    const jualId = newId("jual");
    appendRow("TransaksiJual", {
      id: jualId, orderNo: orderNo, waktu: now, lokasi: p.lokasi, oleh: p.oleh, channel: p.channel,
      totalKotor: totalKotor, komisi: komisi, totalBersih: totalKotor - komisi,
      pelangganNama: p.pelangganNama || "", pelangganHp: p.pelangganHp || "",
    }, ["id", "orderNo", "waktu", "lokasi", "oleh", "channel", "totalKotor", "komisi", "totalBersih", "pelangganNama", "pelangganHp"]);

    itemDetail.forEach((it) => {
      appendRow("TransaksiJualItem", Object.assign({ jualId: jualId }, it), ["jualId", "produkId", "namaProduk", "qty", "harga", "subtotal"]);
    });

    return { orderNo: orderNo, totalKotor: totalKotor, komisi: komisi, totalBersih: totalKotor - komisi };
  } finally {
    lock.releaseLock();
  }
}

// ---------- BELI (selalu masuk ke Gudang) ----------
// payload: { bahanId, qty, supplierId, hargaSatuan, oleh }

function doRecordPurchase(p) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const totalHarga = (p.hargaSatuan || 0) * p.qty;
    ubahStok(p.bahanId, GUDANG, p.qty);
    const id = newId("beli");
    appendRow("TransaksiBeli", {
      id: id, waktu: new Date(), bahanId: p.bahanId, qty: p.qty, supplierId: p.supplierId || "",
      hargaSatuan: p.hargaSatuan || 0, totalHarga: totalHarga, oleh: p.oleh,
    }, ["id", "waktu", "bahanId", "qty", "supplierId", "hargaSatuan", "totalHarga", "oleh"]);
    return { id: id, totalHarga: totalHarga };
  } finally {
    lock.releaseLock();
  }
}

// ---------- TRANSFER (Gudang -> Outlet) ----------
// payload: { bahanId, qty, keLokasi, oleh }

function doRecordTransfer(p) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const stokGudang = getStok(p.bahanId, GUDANG);
    if (!stokGudang || stokGudang.qty < p.qty) throw new Error("Stok gudang tidak cukup untuk transfer.");
    ubahStok(p.bahanId, GUDANG, -p.qty);
    ubahStok(p.bahanId, p.keLokasi, p.qty);
    const id = newId("transfer");
    appendRow("TransaksiTransfer", {
      id: id, waktu: new Date(), bahanId: p.bahanId, qty: p.qty, dariLokasi: GUDANG, keLokasi: p.keLokasi, oleh: p.oleh,
    }, ["id", "waktu", "bahanId", "qty", "dariLokasi", "keLokasi", "oleh"]);
    return { id: id };
  } finally {
    lock.releaseLock();
  }
}
